/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.robotservice;

/**
 *
 * @author dali
 */
public interface RobotService {
     
    
    public void move();
     public void setDirection(String direction);
     public int getX();
     public int getY();
    public String getDirection(String direction);
    
        
    
            
     
}
