/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.lisneer;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import org.emp.gl.timer.service.TimerChangeListener;

/**
 *
 * @author dali
 */
public class ListnerRobot  implements TimerChangeListener{
    
    @Override
    public void propertyChange(PropertyChangeEvent pce) {
       System.out.println("dali"); //To change body of generated methods, choose Tools | Templates.
    }
    
}
