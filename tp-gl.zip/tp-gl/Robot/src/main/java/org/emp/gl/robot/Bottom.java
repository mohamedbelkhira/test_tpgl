/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.robot;

import java.awt.Robot;

/**
 *
 * @author dali
 */
public class Bottom extends State{
    Bottom(RobotM robot)
    {
        super( robot);
        robot.setDirection("Down");
    }
    @Override
    public void move()
    {
        
    }
    
}
