/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.robot;


import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.robotservice.RobotService;

/**
 *
 * @author dali
 */
public class RobotM implements RobotService {
   
   public int x =1;
   public int y=1;
   public State state;
   String direction="Up";
    public RobotM() {
        this.state = new Bottom(this);
        
    }
  
    @Override
    public void move() {
        System.out.println(direction);
        switch(direction){
            case "Right":if(x<9)x++; break;
            case "Left" :if(x>0)x--;break;
            case "Up":if(y<9)y++;break;
            case "Down":if(y>0)y--;break;
            default:break;
            
    
    }
    }

   
    
    @Override
    public String getDirection(String direction) {
       return this.direction;
    }

    @Override
    public void setDirection(String direction) {
       this.direction=direction;
    }

    /**
     *
     * @return
     */
    @Override
    public int getX() {
    return this.x;
    }

    @Override
    public int getY() {
        return this.y;
    }
    public void changeState(State state) {
        this.state = state;
    }
    
   public State getState() {
        return state;
    }
   
   
    }
