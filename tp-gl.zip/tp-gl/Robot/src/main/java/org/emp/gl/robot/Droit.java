/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.robot;
import org.emp.gl.robot.RobotM;
/**
 *
 * @author dali
 */
public class Droit extends State {
    Droit(RobotM robot)
    {
        super( robot);
        robot.setDirection("Right");
    }
    @Override
    public void move()
    {
        
    } 
}
