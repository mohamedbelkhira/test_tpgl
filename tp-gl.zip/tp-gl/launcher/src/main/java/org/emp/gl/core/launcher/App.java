package org.emp.gl.core.launcher;

import javax.swing.SwingUtilities;
import org.emp.gl.affgui.AffGuiServ;

import org.emp.gl.affgui.View;
import org.emp.gl.controllgui.ControllGui;
import org.emp.gl.core.lookup.Lookup;

import org.emp.gl.robot.RobotM;
import org.emp.gl.robotservice.RobotService;

import org.emp.gl.time.service.impl.DummyTimeServiceImpl;
import org.emp.gl.timer.service.TimerChangeListener;
import org.emp.gl.timer.service.TimerService;

/**
 * Hello world!
 *
 */
public class App {

    // ce code nous permettra d'enregistrer les service que notre application utilsiera 
    // lors de l'execution
    static {
        
       
      

        
    }

    public static void main(String[] args) {

        Lookup.getInstance().register(TimerService.class, new DummyTimeServiceImpl());
        Lookup.getInstance().register(RobotService.class, new RobotM());
        testDuTimeService();
    }
    

    private static void testDuTimeService() {
         java.awt.EventQueue.invokeLater(new Runnable() {
           public void run() {
                new ControllGui().setVisible(true);
            }
        });
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            View view =new View();
            view.setVisible(true);
            }
        });
        TimerService ts = Lookup.getInstance().getService(TimerService.class);
        
        ControllGui gui=new ControllGui();
        
        //ts.addTimeChangeListener(new ListnerRobot());
        ts.addTimeChangeListener(new View());
        
        
        
       
            

    }

    public static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }
}
