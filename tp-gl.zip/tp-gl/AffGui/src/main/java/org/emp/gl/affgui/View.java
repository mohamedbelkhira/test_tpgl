/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.affgui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.robotservice.RobotService;
import org.emp.gl.timer.service.TimerChangeListener;

/**
 *
 * @author dali
 */

public class View extends JFrame implements TimerChangeListener{
 RobotService robot= (RobotService)Lookup.getInstance().getService(RobotService.class);
 public int x=1,y=1;
 Graphics g;
 
    
public int [][] maze=        
{ {1,1,1,1,1,1,1,1,1,1},
  {1,0,1,0,1,0,1,0,0,1},
  {1,0,1,0,0,0,1,0,1,1},
  {1,0,0,0,1,1,1,0,0,1},
  {1,0,1,0,0,0,0,0,1,1},
  {1,0,1,0,1,1,1,0,1,1},
  {1,0,1,0,1,0,0,0,1,1},
  {1,0,1,0,1,1,1,0,1,1},
  {1,0,0,0,0,0,0,0,0,1},
  {1,1,1,1,1,1,1,1,1,1}
};
    
    
    public View()
    {
        setTitle("SImple maze");
        setSize(640,480);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
             
    }
   /* void rePaint(Graphics g)
    {   super.paint(g);
        for(int row=0; row<maze.length;row++)
    {   for(int col=0; col<maze[0].length;col++)
        {
            Color color;
            switch(maze[row][col])
              {
                    case 1: color = Color.BLACK;break;
                    case 9: color = Color.RED;break;
                    case 3: color = Color.GREEN; break;
                    default:color= Color.WHITE;
              }
            g.setColor(color);
            g.fillRect(30*col, 30*row, 30, 30);

            g.setColor(Color.BLACK);
            g.drawRect(30*col, 30*row, 30, 30);
        }
  }
    }*/
    
    @Override 
    public void paint(Graphics g)
    {
        super.paint(g);
        
     for(int row=0; row<maze.length;row++)
    {   for(int col=0; col<maze[0].length;col++)
        {
            Color color;
            switch(maze[row][col])
              {
                    case 1: color = Color.BLACK;break;
                    case 9: color = Color.RED;break;
                    case 3: color = Color.GREEN; break;
                    default:color= Color.WHITE;
              }
            g.setColor(color);
            g.fillRect(30*col, 30*row, 30, 30);

            g.setColor(Color.BLACK);
            g.drawRect(30*col, 30*row, 30, 30);
        }
  }
    g.setColor(Color.RED);
    g.drawOval(robot.getX() *30,robot.getY()*30,28,28);
    
    }
    
   


    @Override
    public synchronized void removeWindowListener(WindowListener l) {
        super.removeWindowListener(l); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void propertyChange(PropertyChangeEvent arg0) {
       
        
        robot.move();
        
        
            maze[x][y]=0;
            this.x=robot.getX();
            this.y=robot.getY();
            
            repaint();
        
        
        System.out.println(this.x);
        System.out.println(this.y);
      
        
    }

};